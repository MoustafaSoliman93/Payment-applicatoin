#include "Application/app.h"
ST_accountsDB_t account_dataBase[10];
ST_accountsDB_t* accountP = account_dataBase;
ST_transaction_t transaction_dataBase[10];
ST_transaction_t* transactionP = transaction_dataBase;

int main()
{
	ST_accountsDB_t account1 = { 1000,"284413895218486037" };
	ST_accountsDB_t account2 = { 2000,"734466780919589331" };
	ST_accountsDB_t account3 = { 8000,"188952672792986405" };
	ST_accountsDB_t account4 = { 4500,"294750694523974120" };
	ST_accountsDB_t account5 = { 4000,"848272188961330343" };
	ST_accountsDB_t account6 = { 3000,"953308062854149183" };
	ST_accountsDB_t account7 = { 2000,"2640263953401086" };
	ST_accountsDB_t account8 = { 2500,"7962142303686340" };
	ST_accountsDB_t account9 = { 3500,"6457254249492206" };
	ST_accountsDB_t account10 = { 4500,"5887983376483974" };


	account_dataBase[0] = account1;
	account_dataBase[1] = account2;
	account_dataBase[2] = account3;
	account_dataBase[3] = account4;
	account_dataBase[4] = account5;
	account_dataBase[5] = account6;
	account_dataBase[6] = account7;
	account_dataBase[7] = account8;
	account_dataBase[8] = account9;
	account_dataBase[9] = account10;

	while (1)
	{
		appStart();
	}
}