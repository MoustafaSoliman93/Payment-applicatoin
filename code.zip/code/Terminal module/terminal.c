#include "terminal.h"


EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{
	/***** get the date *****/
	time_t t;
	t = time(NULL);
	struct tm* local = localtime(&t);
	int day, month, year;
	day = local->tm_mday;
	month = local->tm_mon + 1;
	year = local->tm_year + 1900;
	/*****set the format of transaction date****/
	termData->transactionDate[2] = '/';
	termData->transactionDate[5] = '/';
	if (day < 10) {
		termData->transactionDate[0] = '0';
		termData->transactionDate[1] = day + '0';
	}
	else if (day > 9) {
		termData->transactionDate[0] = (day / 10) + '0';
		termData->transactionDate[1] = (day - ((termData->transactionDate[0] - '0') * 10)) + '0';
	}
	if (month < 10) {
		termData->transactionDate[3] = '0';
		termData->transactionDate[4] = month + '0';
	}
	else if (month > 9) {
		termData->transactionDate[3] = (month / 10) + '0';
		termData->transactionDate[4] = (month - ((termData->transactionDate[3] - '0') * 10)) + '0';
	}
	termData->transactionDate[6] = (year / 1000) + '0';
	termData->transactionDate[7] = (year / 100) - ((termData->transactionDate[6] - '0') * 10) + '0';
	termData->transactionDate[8] = (year / 10) - ((termData->transactionDate[6] - '0') * 100) - ((termData->transactionDate[7] - '0') * 10) + '0';
	termData->transactionDate[9] = year - ((termData->transactionDate[6] - '0') * 1000) - ((termData->transactionDate[7] - '0') * 100) - ((termData->transactionDate[8] - '0') * 10) + '0';
	termData->transactionDate[10] = '\0';
	return term_OK;
}
EN_terminalError_t isCardExpired(ST_cardData_t cardData, ST_terminalData_t termData)
{
	int card_exp_year = ((cardData.cardExpirationDate[3] - '0') * 10) + (cardData.cardExpirationDate[4] - '0') + 2000;
	int transaction_year = ((termData.transactionDate[6] - '0') * 1000) + ((termData.transactionDate[7] - '0') * 100) + ((termData.transactionDate[8] - '0') * 10) + (termData.transactionDate[9] - '0');
	if (transaction_year > card_exp_year)
	{
		printf("expired card\n");
		return EXPIRED_CARD;
	}
	else if (transaction_year < card_exp_year)
	{
		return term_OK;
	}
	else if (transaction_year == card_exp_year)
	{
		int card_EXP_mon = ((cardData.cardExpirationDate[0] - '0') * 10) + (cardData.cardExpirationDate[1] - '0');
		int transaction_mon = ((termData.transactionDate[3] - '0') * 10) + (termData.transactionDate[4] - '0');
		if (transaction_mon < card_EXP_mon)
		{
			return term_OK;
		}
		else
		{
			printf("expired card\n");
			return EXPIRED_CARD;
		}
	}
	else
	{
		return EXPIRED_CARD;
	}
}
EN_terminalError_t isValidCardPAN(ST_cardData_t* cardData)
{

	int arr[20] = { 0 };
	int i = 0, sum = 0;
	for (i = 0; cardData->primaryAccountNumber[i] != '\0'; i++)
	{
		arr[i] = cardData->primaryAccountNumber[i] - '0';
	}
	for (i = 0; cardData->primaryAccountNumber[i] != '\0'; i += 2)
	{
		arr[i] = arr[i] * 2;
		if (arr[i] > 9)
		{
			arr[i] = arr[i] / 10 + (arr[i] - 10);
		}
	}
	for (i = 0; cardData->primaryAccountNumber[i] != '\0'; i++) {
		sum = sum + arr[i];
	}
	if ((sum % 10) == 0)
	{
		return term_OK;
	}
	else if ((sum % 10) != 0)
	{
		printf("invalid PAN\n");
		return INVALID_CARD;
	}
	else return INVALID_CARD;
}
EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData)
{
	char string[21];
	printf("please enter the transaction amount :\n");
	gets(string);
	string[20] = '\0';
	termData->transAmount = atof(string);

	if (termData->transAmount <= 0)
	{
		return INVALID_AMOUNT;
	}
	else return term_OK;
}
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	if ((termData->transAmount) > (termData->maxTransAmount))
	{
		printf("exceed max amount\n");
		return EXCEED_MAX_AMOUNT;
	}
	else
	{
		return term_OK;
	}
}
EN_terminalError_t setMaxAmount(ST_terminalData_t* termData)
{
	printf("set the max transaction amount to :\n");
	int x = scanf("%f", &termData->maxTransAmount);
	if (termData->maxTransAmount <= 0)
	{
		return INVALID_MAX_AMOUNT;
	}
	else
	{
		return term_OK;
	}
}