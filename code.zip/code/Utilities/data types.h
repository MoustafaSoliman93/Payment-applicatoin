#ifndef DATA_TYPES_H
#define DATA_TYPES_H

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

typedef unsigned char uint8_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;



#endif // DATA_TYPES_H
