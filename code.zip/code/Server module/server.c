#include "server.h"
#include <stdio.h>



EN_serverError_t isValidAccount(ST_cardData_t* cardData)
{
	for (int i = 0; i < 10; i++)
	{
		if (strcmp(cardData->primaryAccountNumber, account_dataBase[i].primaryAccountNumber))
		{
			continue;
		}
		else
		{
			accountP = account_dataBase + i;
			return OK;
		}
	}
	return ACCOUNT_NOT_FOUND;
}
EN_serverError_t isAmountAvailable(ST_terminalData_t* termData)
{
	if (termData->transAmount > accountP->balance)
	{
		return LOW_BALANCE;
	}
	else
	{
		return OK;
	}
}
EN_serverError_t saveTransaction(ST_transaction_t* transData)
{
	if (transactionP == transaction_dataBase + 10)
	{
		return SAVING_FAILED;
	}
	else
	{
		*transactionP = *transData;
		transactionP->transactionSequenceNumber = (transactionP - transaction_dataBase);
		transactionP++;
		return OK;

	}
}
EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t* transData)
{

	for (int i = 0; i < 255; i++)
	{
		if (transactionSequenceNumber == transaction_dataBase[i].transactionSequenceNumber)
		{
			*transData = transaction_dataBase[i];
			return OK;
		}
	}
	return TRANSACTION_NOT_FOUND;
}
EN_cardError_t getCardInfo(ST_cardData_t* cardData)
{
	EN_cardError_t error = card_OK;
	error = getCardHolderName(cardData);
	if (error == card_OK)
	{
		error = getCardPAN(cardData);
		if (error == card_OK)
		{
			error = getCardExpiryDate(cardData);
			return error;
		}
		else
		{
			return error;
		}

	}
	else
	{
		return error;
	}

}
EN_terminalError_t terminalCheck(ST_terminalData_t* termData, ST_cardData_t* cardData)
{
	EN_terminalError_t error = term_OK;
	error = isValidCardPAN(cardData);
	if (error == term_OK)
	{
		getTransactionDate(termData);
		error = isCardExpired(*cardData, *termData);
		if (error == term_OK)
		{
			getTransactionAmount(termData);
			error = isBelowMaxAmount(termData);
			return error;
		}
		else
		{
			return error;
		}
	}
	else
	{
		return error;
	}

}
EN_serverError_t serverCheck(ST_terminalData_t* termData, ST_cardData_t* cardData)
{
	EN_serverError_t error = OK;
	error = isValidAccount(cardData);
	if (error == OK)
	{
		error = isAmountAvailable(termData);
		return error;
	}
	else
	{
		return error;
	}
}
EN_transState_t recieveTransactionData(ST_transaction_t* transData)
{
	ST_terminalData_t term = { 0.0,5000.0,0 };
	ST_cardData_t card = { 0 };
	EN_cardError_t card_error = card_OK;
	EN_terminalError_t terminal_error = term_OK;
	EN_serverError_t server_error = OK;
	do
	{
		card_error = getCardInfo(&card);
	} while (card_error != card_OK);
	current_transaction.cardHolderData = card;
	terminal_error = terminalCheck(&term, &card);
	if (terminal_error == term_OK)
	{
		current_transaction.terminalData = term;
		server_error = serverCheck(&term, &card);
		if (server_error == OK)
		{
			if (transactionP < transaction_dataBase + 10)
			{
				current_transaction.transState = APPROVED;
				accountP->balance -= current_transaction.terminalData.transAmount;
				printf("Transaction Accepted!\n");
			}
			else
			{
				printf("Internal Server Error\n");
				printf("transaction not Accepted\n");
				current_transaction.transState = INTERNAL_SERVER_ERROR;
				return current_transaction.transState;
			}
		}
		else if (server_error == LOW_BALANCE)
		{
			printf("Low balance\n");
			printf("transaction not Accepted\n");
			current_transaction.transState = DECLINED_INSUFFECIENT_FUND;
		}
		else if (server_error == ACCOUNT_NOT_FOUND)
		{
			printf("Declined stolen account\n");
			printf("transaction not Accepted\n");
			current_transaction.transState = DECLINED_STOLEN_CARD;
		}

		saveTransaction(&current_transaction);

		return current_transaction.transState;
	}
	else
	{
		printf("transaction not complete\n");
		return terminal_error;

	}
}
