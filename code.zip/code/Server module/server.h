#ifndef SERVER_H
#define SERVER_H
#include "../Terminal module/terminal.h"

typedef enum EN_transState_t
{
	APPROVED, DECLINED_INSUFFECIENT_FUND, DECLINED_STOLEN_CARD, INTERNAL_SERVER_ERROR
}EN_transState_t;
typedef enum EN_serverError_t
{
	OK, SAVING_FAILED, TRANSACTION_NOT_FOUND, ACCOUNT_NOT_FOUND, LOW_BALANCE
}EN_serverError_t;
typedef struct ST_accountsDB_t
{
	double balance;
	uint8_t primaryAccountNumber[20];
}ST_accountsDB_t;
typedef struct ST_transaction_t
{
	ST_cardData_t cardHolderData;
	ST_terminalData_t terminalData;
	EN_transState_t transState;
	uint64_t transactionSequenceNumber;
}ST_transaction_t;

EN_transState_t recieveTransactionData(ST_transaction_t* transData);
EN_serverError_t isValidAccount(ST_cardData_t* cardData);
EN_serverError_t isAmountAvailable(ST_terminalData_t* termData);
EN_serverError_t saveTransaction(ST_transaction_t* transData);
EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t* transData);

EN_cardError_t getCardInfo(ST_cardData_t* cardData);
EN_terminalError_t terminalCheck(ST_terminalData_t* termData, ST_cardData_t* cardData);
EN_serverError_t serverCheck(ST_terminalData_t* termData, ST_cardData_t* cardData);


extern ST_accountsDB_t account_dataBase[10];
extern ST_accountsDB_t* accountP;
extern ST_transaction_t transaction_dataBase[10];
extern ST_transaction_t* transactionP;
ST_transaction_t current_transaction;

#endif // SERVER_H
