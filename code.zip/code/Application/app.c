#include "App.h"


extern ST_transaction_t transaction_dataBase[10];
ST_cardData_t card;
ST_terminalData_t term;
unsigned int account_number;
EN_terminalError_t terminal_error = term_OK;
EN_serverError_t server_error = OK;
EN_transState_t transaction_state;


void appStart(void)
{
	char answer[2] = { 'n' };
	printf("do you want to start a new transaction ? y/n\n");
	gets(answer);
	if (answer[0] == 'y')
	{
		printf("\n");
		printf("\n");
		printf("/*********************** START A NEW TRANSACTION ***********************/\n");
		printf("\n");
		recieveTransactionData(&current_transaction);
		printf("\n");
		printf("\n");
		printf("/*********************** TRANSACTION ENDED ***********************/\n");
		printf("\n");
	}
}
