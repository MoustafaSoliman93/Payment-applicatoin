#ifndef APP_H
#define APP_H

#include "../Server module/server.h"

void appStart(void);

#endif // APP_H
