#ifndef CARD_H
#define CARD_H
#include "../Utilities/data types.h"



typedef struct ST_cardData_t
{
	uint8_t cardHolderName[50];
	uint8_t primaryAccountNumber[50];
	uint8_t cardExpirationDate[15];
}ST_cardData_t;
typedef enum EN_cardError_t
{
	card_OK, WRONG_NAME, WRONG_EXP_DATE, WRONG_PAN
}EN_cardError_t;

EN_cardError_t getCardHolderName(ST_cardData_t* cardData);
EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData);
EN_cardError_t getCardPAN(ST_cardData_t* cardData);
char* gets(char* str);






#endif // CARD_H
