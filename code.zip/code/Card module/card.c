#include "card.h"

EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{

	printf("please enter the name on the card :\n");
	gets(cardData->cardHolderName);
	/***** check count *****/

	if ((strlen(cardData->cardHolderName) < 20) || (strlen(cardData->cardHolderName) > 25))
	{
		printf("WRONG NAME\n");
		return WRONG_NAME;
	}
	else
	{
		return card_OK;
	}
}
EN_cardError_t getCardPAN(ST_cardData_t* cardData)
{
	printf("please enter the card PAN :\n");
	gets(cardData->primaryAccountNumber);

	/***** check length *****/
	int length = (int)strlen(cardData->primaryAccountNumber);
	if ((length > 19) || (length < 16))
	{
		printf("INVALID PAN\n");
		return WRONG_PAN;
	}
	/***** check the format *****/
	for (int i = 0; i < length; i++)
	{
		int x = cardData->primaryAccountNumber[i];
		if ((x > '9') || (x < '0'))
		{
			printf("INVALID PAN\n");
			return WRONG_PAN;
		}

	}
	return card_OK;
}
EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData)
{
	printf("please enter the exp date in this format mm/yy :\n");
	gets(cardData->cardExpirationDate);

	/***** check lenghth *****/
	if (strlen(cardData->cardExpirationDate) != 5)
	{
		printf("wrong EXP date\n");
		return WRONG_EXP_DATE;
	}
	/***** check the format *****/
// chech '/' character 
	if ((cardData->cardExpirationDate[2] != '/'))
	{
		printf("wrong EXP date\n");
		return WRONG_EXP_DATE;
	}
	// check the month number
	int x = (cardData->cardExpirationDate[0] - '0') * 10 + (cardData->cardExpirationDate[1] - '0');
	if ((x > 12) || (x < 1))
	{
		printf("wrong EXP date\n");
		return WRONG_EXP_DATE;
	}
	//check the year number
	x = cardData->cardExpirationDate[3];
	if ((x > '9') || (x < '0'))
	{
		printf("wrong EXP date\n");
		return WRONG_EXP_DATE;
	}
	x = cardData->cardExpirationDate[4];
	if ((x > '9') || (x < '0'))
	{
		printf("wrong EXP date\n");
		return WRONG_EXP_DATE;
	}

	return card_OK;
}